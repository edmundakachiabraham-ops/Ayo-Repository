# Deploying S&S Divina to Hostinger

Your site has two parts that get deployed differently:

- **Frontend** — `ss-divina-homepage.html`, `men.html`, `cart.html`, etc. + the `videos/` folder.
  These are plain static files. Any Hostinger plan can serve these.
- **Backend** — the Express API in `/backend`. This is a **Node.js server that
  has to stay running**, not a static file. This needs a hosting plan that
  supports Node.js.

Read step 0 before you buy/confirm a plan — it decides how the rest goes.

---

## Step 0 — Check what your Hostinger plan supports

Hostinger's regular **shared hosting** (Single/Premium/Business "Web
Hosting" plans) is built for static files and PHP — it does **not** run a
persistent Node.js process. Hostinger's **Cloud Startup/Professional/Business**
and **VPS** plans do support Node.js apps (in hPanel under **Advanced → Node.js**,
or full control on a VPS).

You have two honest options:

**Option A — Everything on Hostinger.** Works if you're on a Cloud or VPS
plan with Node.js support. Follow Steps 1–4 below as written.

**Option B — Frontend on Hostinger, backend elsewhere.** Works on *any*
Hostinger plan, including basic shared hosting. Put the static files on
Hostinger as normal, and deploy the `/backend` folder to a Node-friendly host
like [Render](https://render.com) or [Railway](https://railway.app) (both
have free tiers that are enough for a starter store). This is the path most
people on ordinary Hostinger web hosting should take. Steps 1 and 3 still
apply; for Step 2, deploy to Render/Railway instead of hPanel's Node.js tool,
following that host's "deploy from a folder/GitHub repo" instructions —the
`backend/README.md` already documents every environment variable it needs.

Either way, the frontend ends up talking to the backend over a URL like
`https://api.yourdomain.com` or `https://ssdivina-api.onrender.com` — there's
no scenario where they need to be on the same host.

---

## Step 1 — Upload the frontend

1. In **hPanel → Files → File Manager**, open `public_html` (this is your
   site's root — whatever's in here becomes `yourdomain.com/...`).
2. Upload every `.html` file (`ss-divina-homepage.html`, `men.html`,
   `women.html`, `product.html`, `my-account.html`, `cart.html`,
   `checkout.html`, `order-confirmation.html`, `the-house.html`,
   `new-arrivals.html`, `best-sellers.html`, `shop-az.html`) directly into
   `public_html`.
3. Upload the whole `videos/` folder into `public_html` too, so you end up
   with `public_html/videos/hero-1.mp4`, etc. Don't rename anything — the
   pages reference these exact filenames.
4. Rename `ss-divina-homepage.html` to `index.html` **or** create a tiny
   `index.html` that redirects to it, so `yourdomain.com` (with nothing
   after it) loads your homepage:
   ```html
   <meta http-equiv="refresh" content="0; url=ss-divina-homepage.html">
   ```
   (Renaming to `index.html` is cleaner — just make sure every internal link
   still says `ss-divina-homepage.html` in `href`, or find-and-replace those
   to `index.html` too, in File Manager's editor or before you upload.)
5. In **hPanel → Websites → [your site] → SSL**, turn SSL on (Hostinger
   issues a free Let's Encrypt certificate). Your site should load at
   `https://yourdomain.com`.

At this point the site loads and looks right, but nothing that needs the
backend works yet (login, cart, checkout) — that's Step 2.

---

## Step 2 — Deploy the backend

### If your plan supports Node.js (hPanel path)

1. **hPanel → Advanced → Node.js → Create Application.**
2. Application root: upload the contents of `/backend` here (via File
   Manager or Git — Hostinger's Node.js tool supports pulling from a Git repo,
   which is the easier path if you push this project to GitHub first).
3. **Startup file:** `server.js`
4. **Node.js version:** 18 or newer.
5. In the same screen, add environment variables — copy every key from
   `backend/.env.example` and fill in real values (JWT_SECRET, Paystack keys,
   CORS_ORIGIN set to `https://yourdomain.com`, COOKIE_SECURE=true).
6. Click **Run NPM Install** (Hostinger's panel button for this), then
   **Run NPM script → seed** (or open the app's built-in terminal and run
   `npm run seed` yourself) to create `data/db.json`.
7. Start the app. Hostinger will give it an internal port; the panel
   normally lets you map a subdomain (e.g. `api.yourdomain.com`) straight to
   it — do that so you get a clean public URL. If your plan doesn't offer
   that mapping, set up the subdomain under **Domains → Subdomains** and
   point it at the app per Hostinger's Node.js docs for your plan.

### If you're on shared hosting (Render path — recommended for most people)

1. Push the `/backend` folder to a GitHub repo (or use Render's manual
   deploy with a zip).
2. On [render.com](https://render.com): **New → Web Service**, connect the
   repo, set:
   - Build command: `npm install`
   - Start command: `npm run seed && npm start`
   - Add every variable from `backend/.env.example` under **Environment**.
3. Render gives you a URL like `https://ss-divina-backend.onrender.com` —
   that's your API base for Step 3. (Optional: add a custom subdomain like
   `api.yourdomain.com` under Render's **Settings → Custom Domains**, then
   create a matching CNAME record in **hPanel → Domains → DNS Zone Editor**
   pointing to the address Render gives you.)

Either way, confirm it's alive before moving on:
```
https://your-backend-url/api/health
```
should return `{"ok":true,"service":"ss-divina-backend"}`.

---

## Step 3 — Point the frontend at the live backend

Every frontend page has one line near the top of its `<script>` block:

```js
const API_BASE = 'http://localhost:4000/api';
```

This appears in: `ss-divina-homepage.html`, `men.html`, `women.html`,
`product.html`, `my-account.html`, `cart.html`, `checkout.html`,
`order-confirmation.html`, `the-house.html`, `new-arrivals.html`,
`best-sellers.html`, `shop-az.html`.

Change it in **all of them** to your live backend URL, e.g.:

```js
const API_BASE = 'https://api.yourdomain.com/api';
```

Fastest way: edit one file in a text editor, use Find & Replace across the
whole project folder for `http://localhost:4000/api`, then re-upload the
changed files to `public_html` (overwriting the old ones).

---

## Step 4 — Final checks

1. Update `backend`'s `.env` (wherever it's actually running):
   - `CORS_ORIGIN=https://yourdomain.com` (must match your live frontend
     origin exactly, including `https://`)
   - `COOKIE_SECURE=true` (both frontend and backend must be on HTTPS for
     login/cart cookies to work — Hostinger's and Render's free SSL both
     cover this)
   - Real Paystack keys (`pk_live_…` / `sk_live_…`) once you're ready to
     take real payments — test keys (`pk_test_…`) are fine while you're
     still checking everything works
2. Restart the backend app after any `.env` change.
3. Walk through the whole flow on the live site: register an account →
   browse to a product → add to bag → checkout with a
   [Paystack test card](https://paystack.com/docs/payments/test-payments/) →
   confirm the order shows up under **My Account → Orders**.
4. If something doesn't load, open your browser's DevTools → Console/Network
   tab — a failed `fetch` to the wrong `API_BASE`, or a CORS error, are the
   two most common first-deploy issues, and both point straight to Steps 2–3.

---

## Quick reference — what goes where

```
Hostinger public_html/          (or wherever your static host serves from)
├── index.html                  (renamed from ss-divina-homepage.html)
├── men.html
├── women.html
├── product.html
├── my-account.html
├── cart.html
├── checkout.html
├── order-confirmation.html
├── the-house.html
├── new-arrivals.html
├── best-sellers.html
├── shop-az.html
└── videos/
    ├── hero-1.mp4 / hero-1-poster.jpg
    ├── hero-2.mp4 / hero-2-poster.jpg
    └── hero-3.mp4 / hero-3-poster.jpg

Hostinger Node.js app  (or Render/Railway) — completely separate
└── backend/
    ├── server.js, package.json, .env, ...
    └── (everything from the backend zip)
```
